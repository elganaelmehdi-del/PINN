# =========================================================
# 1D Subcritical flow over a movable bump (Test 3) + DATASET GENERATION
# First-order explicit finite-volume scheme (Rusanov flux) for the
# shallow water–Exner system; writes the reference solution
# "Subcritical steady state over a moveable bump.mat" used by the PINN notebooks.
# =========================================================

import numpy as np
import matplotlib.pyplot as plt
import scipy.io

# =========================================================
# PARAMETERS
# =========================================================
g = 9.81
Ag = 5e-3
m = 3
CFL = 0.4
Nx = 500
L = 10.0
dx = L / Nx
x = np.linspace(0, L, Nx)

Tfinal = 10
hmin = 1e-4

# =========================================================
# INITIAL CONDITIONS (steady subcritical flow over a bump)
# =========================================================
def compute_hini_np(x):
    q = 0.5
    z = 0.1+0.1*np.exp(-(x-5)**2)
    E = 6.386
    h = np.ones_like(x) * 0.5
    for _ in range(50):
        f = q**2 / (2.0 * h**2) + g * (h + z) - E
        df = -q**2 / (h**3) + g
        h = h - f / df
        h = np.maximum(h, 1e-6)
    return h

h = compute_hini_np(x)
hu = 0.5*np.ones_like(x)

# Bed
z = 0.1+0.1*np.exp(-(x-5)**2)

# =========================================================
# FUNCTIONS
# =========================================================
def velocity(h, hu):
    return np.where(h > hmin, hu / h, 0.0)

def sediment_flux(u):
    return Ag * np.abs(u)**(m - 1) * u

def compute_dt(h, u):
    c = np.sqrt(g * h)
    return CFL * dx / (np.max(np.abs(u) + c) + 1e-8)

def rusanov_flux(U_L, U_R):
    hL, huL = U_L
    hR, huR = U_R

    uL = huL / hL if hL > hmin else 0.0
    uR = huR / hR if hR > hmin else 0.0

    FL = np.array([
        huL,
        huL * uL + 0.5 * g * hL**2
    ])

    FR = np.array([
        huR,
        huR * uR + 0.5 * g * hR**2
    ])

    a = max(abs(uL) + np.sqrt(g * hL),
            abs(uR) + np.sqrt(g * hR))

    return 0.5 * (FL + FR) - 0.5 * a * (U_R - U_L)

# =========================================================
# STORAGE INITIALIZATION
# =========================================================
t = 0.0

time_list = [t]
H = [h.copy()]
HU = [hu.copy()]
Z = [z.copy()]

# =========================================================
# TIME LOOP
# =========================================================
while t < Tfinal:
    u = velocity(h, hu)
    dt = compute_dt(h, u)

    if t + dt > Tfinal:
        dt = Tfinal - t

    # Flux arrays
    Fh = np.zeros(Nx + 1)
    Fhu = np.zeros(Nx + 1)
    Fz = np.zeros(Nx + 1)

    Qs = sediment_flux(u)

    # Interior fluxes
    for i in range(1, Nx):
        flux = rusanov_flux(
            np.array([h[i-1], hu[i-1]]),
            np.array([h[i],   hu[i]])
        )
        Fh[i], Fhu[i] = flux

        az = abs(u[i])
        Fz[i] = 0.5 * (Qs[i-1] + Qs[i]) - 0.5 * az * (z[i] - z[i-1])

    # Bed slope
    dzdx = np.zeros_like(z)
    dzdx[1:-1] = (z[2:] - z[:-2]) / (2 * dx)

    # Update
    h_new = h.copy()
    hu_new = hu.copy()
    z_new = z.copy()

    for i in range(1, Nx-1):
        h_new[i] = h[i] - dt/dx * (Fh[i+1] - Fh[i])

        hu_new[i] = (
            hu[i]
            - dt/dx * (Fhu[i+1] - Fhu[i])
            - dt * g * h[i] * dzdx[i]
        )

        z_new[i] = z[i] - dt/dx * (Fz[i+1] - Fz[i])

    # Positivity + BCs
    h_new = np.maximum(h_new, hmin)

    h_new[0], h_new[-1] = h_new[1], h_new[-2]
    hu_new[0], hu_new[-1] = hu_new[1], hu_new[-2]
    z_new[0], z_new[-1] = z_new[1], z_new[-2]

    # Update state
    h, hu, z = h_new, hu_new, z_new
    t += dt

    # Store data
    time_list.append(t)
    H.append(h.copy())
    HU.append(hu.copy())
    Z.append(z.copy())

# =========================================================
# CONVERT TO PINN FORMAT
# =========================================================
H = np.array(H)   # (Nt, Nx)
HU = np.array(HU)
Z = np.array(Z)
t_array = np.array(time_list)

# Velocity
U = np.where(H > hmin, HU / H, 0.0)

# Transpose → (Nx, Nt)
H = H.T
U = U.T
Z = Z.T

# =========================================================
# SAVE DATASET
# =========================================================
data_dict = {
    'x': x.reshape(-1, 1),
    't': t_array.reshape(-1, 1),
    'h': H,
    'u': U,
    'z': Z
}

scipy.io.savemat('Subcritical steady state over a moveable bump.mat', data_dict)

print("✅ Subcritical steady state over a moveable bump.mat")
print("Shapes:")
print("h:", H.shape, "u:", U.shape, "z:", Z.shape)

# =========================================================
# PLOT FINAL STATE
# =========================================================
u = velocity(h, hu)

plt.figure(figsize=(10,7))

plt.subplot(3,1,1)
plt.plot(x, h+z)
plt.ylabel("Water depth h")

plt.subplot(3,1,2)
plt.plot(x, u)
plt.ylabel("Velocity u")

plt.subplot(3,1,3)
plt.plot(x, z)
plt.ylabel("Bed elevation z")
plt.xlabel("x")

plt.tight_layout()
plt.show()
