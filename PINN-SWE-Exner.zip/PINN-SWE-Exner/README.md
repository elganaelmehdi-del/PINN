# Adaptive Dynamic Patch PINNs for the coupled Shallow Water–Exner system

Code accompanying the manuscript

> E. M. El Gana, M. El Kihel, A. Taleb, A. Ouallali, *Adaptive Dynamic Patch PINNs for Morphodynamic
> Modeling of the Coupled Shallow Water–Exner System*, Engineering Research Express (manuscript ERX-120869, under review).

The repository contains the four PINN training strategies compared in the paper, the finite-volume
solvers that generate the reference solutions, and the scripts used to produce the figures.

| Strategy | Paper section | File in each test folder |
|---|---|---|
| Standard MLP PINN | 2.2.1 | `01_mlp_pinn.ipynb` |
| Residual-based adaptive refinement (RAR, DeepXDE) | 2.2.2, Algorithm 1 | `02_rar_deepxde.ipynb` |
| Sequential space–time patch PINN | 2.2.3, Algorithm 2 | `03_sequential_patch_pinn.ipynb` |
| Adaptive dynamic patch PINN (proposed) | 2.2.4, Algorithm 3 | `04_adaptive_patch_pinn.ipynb` |

## Repository structure

```
test1_analytical/          Test 1 – analytical solution (Berthon et al., 2012), x, t in [0, 7]
    01–04 *.ipynb          the four PINN strategies (the exact solution is computed inside each notebook)
    05_plot_comparison     comparison figures
    KAN_nn/mlp.py          MLP network class used by 01_mlp_pinn.ipynb
test2_dam_break/           Test 2 – erodible dam break, x in [0, 10] m, t in [0, 1] s
    00_finite_volume_reference.ipynb   Rusanov finite-volume solver -> dam_break_dataset.mat
    01–04 *.ipynb          the four PINN strategies
    05_mlp_with_sparse_data.ipynb      MLP trained with 100 reference points (Section 4.4, Table 8)
    06_plot_training_log.ipynb         plot of the loss histories from a training log
    07_plot_comparison.ipynb           comparison figures
test3_subcritical_bump/    Test 3 – subcritical flow over a movable bump, x in [0, 10] m, t in [0, 10] s
    00_finite_volume_reference.py      Rusanov finite-volume solver -> "Subcritical steady state over a moveable bump.mat"
    01–04 *.ipynb          the four PINN strategies
    05_plot_comparison.ipynb           comparison figures
```

## Installation

```bash
git clone https://github.com/<user>/PINN-SWE-Exner.git
cd PINN-SWE-Exner
pip install -r requirements.txt
```

A CUDA-capable GPU is recommended; all scripts also run on CPU (more slowly).

## How to reproduce the results

1. **Tests 2 and 3 only:** first run the finite-volume solver (`00_finite_volume_reference`) in the test folder.
   It creates the reference data set (`.mat`) read by the PINN notebooks; the data files are not stored in the
   repository because they are regenerated in a few seconds.
2. Run the PINN notebooks `01`–`04` from inside the test folder (they read and write files in the working directory).
   Each notebook prints the errors with respect to the reference solution and saves its predictions
   (`comparison_pack_*.npz`).
3. Run the plotting notebook to assemble the comparison figures.

All hyperparameters are written at the top of each notebook (section "Training parameters") and are
summarised in Table 2 of the paper.

## Notes

* **Random seeds.** The MLP, RAR and adaptive patch notebooks fix the seed to 1234; the sequential patch
  notebooks of Tests 2 and 3 do not fix it, so their results vary slightly between runs.
* **Weak data term.** The two patch-based strategies include a weak supervision term (one reference point drawn
  at each iteration, `lambda_data`), as described in Sections 2.2.3 and 3.4 of the paper. Setting
  `lambda_data = 0` gives a purely physics-informed training.
* **Test 1 residuals.** In Test 1, the networks are trained with two compatibility relations satisfied by the
  analytical solution, d/dt d/dx (h + z_b) = 0 and d²/dx² (u³) = 0, together with initial and boundary
  conditions on all variables (Section 2.3.1 of the paper). Tests 2 and 3 use the full shallow water–Exner residuals.
* In `test1_analytical/01_mlp_pinn.ipynb`, the imports of alternative network classes (Jacobi, Fourier, Chebyshev),
  which are not used in the paper, have been commented out; only the MLP is trained.
* The class `KAN_nn/mlp.py` comes from the J-PIKAN code of Xiong et al. (2025), *J-PIKAN: A Physics-Informed KAN
  Network Based on Jacobi Orthogonal Polynomials for solving Fluid Dynamics*, Communications in Nonlinear Science
  and Numerical Simulation, 109414.

## Citation

If you use this code, please cite the paper above (full reference to be updated after publication).

## License

MIT License – see `LICENSE`.
